<!DOCTYPE html>
<html>
<head>
  <title>Upload the file</title>


  <link rel="stylesheet" type="text/css" href="upload.css">
  <link href='https://fonts.googleapis.com/css?family=Work+Sans:400,300,700' rel='stylesheet' type='text/css'>

   <link href="https://fonts.googleapis.com/css?family=Baloo+Tammudu" rel="stylesheet">



  </style>
</head>
<body>

<!--Google Font - Work Sans-->



<div class="container" >
<br>
<span style="font-size: 30px; padding-left: 100px; align-content: center; color: black; font-family: 'Baloo Tammudu', cursive;  ">UPLOAD HERE.
</span> 

<br>
  <div class="profile">
    <button class="profile__avatar" id="toggleProfile">
     <img src="amdocs.png" alt="Avatar" /> 
    </button>



 <form action=" " method="POST" enctype="multipart/form-data">
         <div class="profile__form">
            <input type="file" name="image" />
         <input type="submit"/>
        </div>
      </form>

  </div>
  
</div>


 <script>
   document.getElementById('toggleProfile').addEventListener('click', function () {
  [].map.call(document.querySelectorAll('.profile'), function(el) {
    el.classList.toggle('profile--open');
  });
});
 </script>

<?php
   if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $expensions= array("xls","xlsx");
      
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
      
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"uploads/".$file_name);
       

require_once "Classes/PHPExcel.php";

    $tmpfname = "uploads/".$file_name ;
    $excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
    $excelObj = $excelReader->load($tmpfname);
  //  $worksheet = $excelObj->getSheet(1);
  //  $worksheet2 = $excelObj->getSheet(2);
    $worksheet5 = $excelObj->getSheet(5);
    $worksheet1 = $excelObj->getSheet(1);


    $lastRow5 = $worksheet5->getHighestRow();
    $lastRow1 = $worksheet1->getHighestRow();

    $cr = $worksheet1->getCell('C'.'5')->getValue();
    $pmt_id = $worksheet1->getCell('C'.'6')->getValue();
echo $cr;
echo '<br>';
echo $pmt_id;
  //  $lastcol = $worksheet->getHighestColumn();

 /*echo $worksheet->getCell('C'.'5')->getValue();
 echo '<br>';
 echo $worksheet2->getCell('B'.'3')->getValue();
 echo '<br>';
 echo $worksheet->getCell('C'.'6')->getValue();*/

 
  $html_table = '<table>';

  $c = 'A';
$chars = array($c);
while ($c < 'Z') $chars[] = ++$c;
foreach ($chars as $key => $value) 
  {
    for ($row = 1; $row <= $lastRow5; $row++) {
      
             echo "<tr><td>";
            $html_table .= $worksheet5->getCell($value.$row)->getValue();
         echo "</td><tr>";
         /*
       echo "</td><td>";
       echo $worksheet3->getCell('B'.$row)->getValue();
       echo "</td><td>";
       echo $worksheet3->getCell('C'.$row)->getValue();
       echo "</td><td>";
       echo $worksheet3->getCell('D'.$row)->getValue();
       echo "</td><td>";
       echo $worksheet3->getCell('E'.$row)->getValue();
       echo "</td><td>";
       echo $worksheet3->getCell('F'.$row)->getValue(); 
       echo "</td><tr>";*/
      
    } }
    $html_table .=  '</table>';

 $text_info_new = substr_count($html_table, 'New'); 
 $text_info_new_modify = substr_count($html_table, 'New/Modify'); 
 $text_info_modify = substr_count($html_table, 'Modify'); 
echo '<br>';

 $new_count =  $text_info_new - $text_info_new_modify;
 echo '<br>';
 $modify_count =  $text_info_modify - $text_info_new_modify;





$con= mysqli_connect("localhost","root","","dgs");

if (mysqli_connect_errno () )
 {
    echo "Connection is not established";
}


$insert_data = "INSERT INTO dg_table (cr_number, pmt_id, new_count, modify_count, name) VALUES ('$cr', '$pmt_id' , '$new_count' , '$modify_count' , '$file_name') " ;



if (mysqli_query($con, $insert_data)) {
  echo "<script>alert('Data inserted')</script>";  
   echo "<script>window.open('list.php','_self')</script>";

}










}














else{
         print_r($errors);
      }
   }


?>
</body>
</html>


 






