<!DOCTYPE html>

<?php

$dg_data = "SELECT name, cr_number, pmt_id, sum(new_count) as max_new_count , sum(modify_count) as max_modify_count, object_name, object_type  from dg_table where object_name = 'mas' ;";

$run_pro = mysqli_query($con, $dg_data);

?>
<html>
<head>
  <title></title>
</head>
<body>
<div class="col-lg-8">

              
  <table class="table table-striped">
    <thead>
      <tr>

   
        <th>Object Name</th>
        <th>Total New Elements</th>
        <th>Total Modify Elements</th>


      </tr>
    </thead>

      <?php

while ($row_pro = mysqli_fetch_array($run_pro))
{



$cr_number = $row_pro['cr_number'];
$pmt_id = $row_pro['pmt_id'];
$new_count = $row_pro['max_new_count'];
$modify_count = $row_pro['max_modify_count'];
$filename = $row_pro['name'];
$objname = $row_pro['object_name'];
$objtype = $row_pro['object_type'];

      ?>



    <tbody>
      <tr>

    
        <td> <?php echo $objname ; ?> </td>
      
        <td> <?php echo $new_count ; ?></td>
        <td> <?php echo $modify_count ; ?></td>


        
        

      </tr>
      
    </tbody>




<?php

}



?>


  </table>





<div class="container">
   
   <div id="piechart" style="width: 900px; height: 500px;"></div>
</div>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

<?php
$new_count_chart = 1;
$modify_count_chart = 1;


    
          
          $col_chart ="SELECT sum(new_count) as new_one, sum(modify_count) as modify_one FROM dg_table  where object_name = 'mas' ";
$run_chart = mysqli_query($con, $col_chart);
$row_chart = mysqli_fetch_array($run_chart);

            $new_count_chart = $row_chart['new_one']  ;
         $modify_count_chart = $row_chart['modify_one'];
       

    


  

?>



      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['New',     <?php echo $new_count_chart;  ?>],
          ['Modified', <?php echo $modify_count_chart; ?>],
          
        ]);

        var options = {
          title: 'Maestro Objects'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>





</div>




</body>
</html>