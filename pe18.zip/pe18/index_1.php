<!DOCTYPE html>
<html>
<head>
	<title>Test</title>
</head>
<body>





<?php
if (isset($_GET['file_name'])) {
  

 
  $filetoupload = $_GET['file_name'];


$con= mysqli_connect("localhost","root","","dgs");

if (mysqli_connect_errno () )
 {
    echo "Connection is not established";
}



require_once "Classes/PHPExcel.php";

    $tmpfname = "upload_test/".$filetoupload;


    $excelReader = PHPExcel_IOFactory::createReaderForFile($tmpfname);
    $excelObj = $excelReader->load($tmpfname);
  //  $worksheet = $excelObj->getSheet(1);
  //  $worksheet2 = $excelObj->getSheet(2);

 $sheetNames = $excelObj->getSheetNames();




   foreach ($sheetNames as $key => $sheetValues) {
      
      

         if ($sheetValues == 'TDBA-VDBA Checklist') {
           $tdba =  $key;
           echo $tdba;
         }

            
         if ($sheetValues == 'Object Summary') {
           $object_summary =  $key;
           echo $object_summary;
         }


   }











    $worksheet5 = $excelObj->getSheet($object_summary);
    $worksheet1 = $excelObj->getSheet($tdba);


    $lastRow5 = $worksheet5->getHighestRow();
    $lastRow1 = $worksheet1->getHighestRow();

    $cr = $worksheet1->getCell('C'.'5')->getValue();
    $pmt_id = $worksheet1->getCell('C'.'6')->getValue();






  //  $lastcol = $worksheet->getHighestColumn();

 /*echo $worksheet->getCell('C'.'5')->getValue();
 echo '<br>';
 echo $worksheet2->getCell('B'.'3')->getValue();
 echo '<br>';
 echo $worksheet->getCell('C'.'6')->getValue();*/


echo '<table>';

 
 // $html_table  = '<table>';


  $c = 'A';
$chars = array($c);
while ($c < 'Z') $chars[] = ++$c;
foreach ($chars as $key => $value) 
  {
    for ($row = 1; $row <= $lastRow5; $row++) {
     
echo "<tr><td>";
//            $html_table .= $worksheet5->getCell($value.$row)->getValue();
 $var_unt=  $worksheet5->getCell($value.$row)->getValue();

$var = trim($var_unt);


//Shell Scripts

if ($var == 'Shell Scripts' ) {

$row_value = $row;

$row_1 = $row + 1;
$row_2 = $row + 2;
$row_3 = $row + 3;

$var_object_unt_1 = $worksheet5->getCell($value.$row_1)->getValue();

$var_object_unt_2 = $worksheet5->getCell($value.$row_2)->getValue();

$var_object_unt_3 = $worksheet5->getCell($value.$row_3)->getValue();


if (($var_object_unt_1 == NULL) || ($var_object_unt_2 == NULL) ) 
{
  
   $excelObj->getSheet(5)->setCellValue($value.$row_2,'Empty');
    
}


for ($j = $row  ; $j <= $lastRow5; $j++)
{


$var_object_unt = $worksheet5->getCell($value.$j)->getValue();






$var_object_null = trim($var_object_unt);

if ($lastRow5 == $j) {
  $shell[] = $j;
}




if ($var_object_null == NULL || $var_object_null == 'Informatica Objects' || $var_object_null == 'Teradata Objects' || $var_object_null == 'Maestro') {
  

$shell[] = $j; 

}


}

$d = $value;
$chars_1 = array($d);
while ($d < 'Z') $chars_1[] = ++$d;
foreach ($chars_1 as $key => $nextvalue) 
{


$object_name = $chars_1[0];
$object_type_count = $chars_1[1];
 $new_modify_value = $chars_1[2];
$shell_new_count_s = 0;
$shell_modify_count_s = 0;
$shell_new_count_b = 0;
$shell_modify_count_b = 0;
$shell_new_count_m = 0;
$shell_modify_count_m = 0;
$shell_new_count_t = 0;
$shell_modify_count_t = 0;
$shell_new_count_k = 0;
$shell_modify_count_k = 0;
$shell_new_count_d = 0;
$shell_modify_count_d = 0;
$shell_new_count_f = 0;
$shell_modify_count_f = 0;
$shell_new_count_x = 0;
$shell_modify_count_x = 0;




for ($i=$row; $i < $shell[0]; $i++) { 
 

 $var_object_type =  $worksheet5->getCell($object_type_count.$i)->getValue();

$var_object_name = $worksheet5->getCell($object_name .$i)->getValue();


  
if ($var_object_type == 'S') {


 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $shell_new_count_s++;
}


if ($var_new_modify_type == 'Modify') {
 $shell_modify_count_s++;



}
}






if ($var_object_type == 'B') {


 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $shell_new_count_b++;
}


if ($var_new_modify_type == 'Modify') {
 $shell_modify_count_b++;

}
}

if ($var_object_type == 'M') {


 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $shell_new_count_m++;
}


if ($var_new_modify_type == 'Modify') {
 $shell_modify_count_m++;
}
}






if ($var_object_type == 'T') {


 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $shell_new_count_t++;
}


if ($var_new_modify_type == 'Modify') {
 $shell_modify_count_t++;
}
}





if ($var_object_type == 'K') {


 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $shell_new_count_k++;
}


if ($var_new_modify_type == 'Modify') {
 $shell_modify_count_k++;
}
}




if ($var_object_type == 'D') {


 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $shell_new_count_d++;
}


if ($var_new_modify_type == 'Modify') {
 $shell_modify_count_d++;
}
}





if ($var_object_type == 'F') {


 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $shell_new_count_f++;
}


if ($var_new_modify_type == 'Modify') {
 $shell_modify_count_f++;
}
}




if ($var_object_type == 'X') {


 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $shell_new_count_x++;
}


if ($var_new_modify_type == 'Modify') {
 $shell_modify_count_x++;
}
}







}
}

}


//Informatica Objects

if ($var == 'Informatica Objects') {


$row_value = $row;

for ($j = $row; $j <= $lastRow5; $j++)
{
  $var_object_unt = $worksheet5->getCell($value.$j)->getValue();

$var_object_null = trim($var_object_unt);



if ($lastRow5 == $j) {
  $inf[] = $j;
}


if ($var_object_null == NULL || $var_object_null == 'Shell Scripts' || $var_object_null == 'Teradata Objects' || $var_object_null == 'Maestro') {
  
$inf[] = $j; 

}


}





$d = $value;
$chars_1 = array($d);
while ($d < 'Z') $chars_1[] = ++$d;
foreach ($chars_1 as $key => $nextvalue) 

{

$object_type_count = $chars_1[1];
$new_modify_value = $chars_1[2];
$inf_new_count_sc = 0;
$inf_modify_count_sc = 0;
$inf_new_count_t = 0;
$inf_modify_count_t = 0;
$inf_new_count_m = 0;
$inf_modify_count_m = 0;
$inf_new_count_s = 0;
$inf_modify_count_s = 0;
$inf_new_count_w = 0;
$inf_modify_count_w = 0;
$inf_new_count_mi = 0;
$inf_modify_count_mi = 0;





for ($i=$row; $i < $inf[0]; $i++) { 
 

 $var_object_type =  $worksheet5->getCell($object_type_count.$i)->getValue();

if ($var_object_type == 'Sc') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $inf_new_count_sc++;
}

if ($var_new_modify_type == 'Modify') {
  $inf_modify_count_sc++;
}
}


if ($var_object_type == 'T') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $inf_new_count_t++;
}

if ($var_new_modify_type == 'Modify') {
  $inf_modify_count_t++;
}
}


if ($var_object_type == 'M') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $inf_new_count_m++;
}

if ($var_new_modify_type == 'Modify') {
  $inf_modify_count_m++;
}
}



if ($var_object_type == 'S') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $inf_new_count_s++;
}

if ($var_new_modify_type == 'Modify') {
  $inf_modify_count_s++;
}
}


if ($var_object_type == 'W') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $inf_new_count_w++;
}

if ($var_new_modify_type == 'Modify') {
  $inf_modify_count_w++;
}
}




if ($var_object_type == 'MI') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $inf_new_count_mi++;
}

if ($var_new_modify_type == 'Modify') {
  $inf_modify_count_mi++;
}
}




}
}
}


//Teradata

if ($var == 'Teradata Objects') {


$row_value = $row;

for ($j = $row; $j <= $lastRow5; $j++)
{
  $var_object_unt = $worksheet5->getCell($value.$j)->getValue();

$var_object_null = trim($var_object_unt);

if ($lastRow5 == $j) {
  $td[] = $j;
}



if ($var_object_null == NULL || $var_object_null == 'Informatica Objects' || $var_object_null == 'Shell Scripts' || $var_object_null == 'Maestro') {
 


$td[] = $j; 



}


}




$d = $value;
$chars_1 = array($d);
while ($d < 'Z') $chars_1[] = ++$d;
foreach ($chars_1 as $key => $nextvalue) 

{

$object_type_count = $chars_1[1];
$new_modify_value = $chars_1[2];
$td_new_count_t = 0;
$td_modify_count_t = 0;

$td_new_count_v= 0;
$td_modify_count_v = 0;


$td_new_count_s = 0;
$td_modify_count_s = 0;


$td_new_count_g = 0;
$td_modify_count_g = 0;





for ($i=$row; $i < $td[0]; $i++) { 
 

 $var_object_type =  $worksheet5->getCell($object_type_count.$i)->getValue();




if ($var_object_type == 'T') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $td_new_count_t++;
}

if ($var_new_modify_type == 'Modify') {
  $td_modify_count_t++;
}
}

if ($var_object_type == 'V') {

  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $td_new_count_v++;
}

if ($var_new_modify_type == 'Modify') {
  $td_modify_count_v++;


}
}




if ($var_object_type == 'S') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $td_new_count_s++;
}

if ($var_new_modify_type == 'Modify') {
  $td_modify_count_s++;
}
}


if ($var_object_type == 'G') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $td_new_count_g++;
}

if ($var_new_modify_type == 'Modify') {
  $td_modify_count_g++;
}
}



}
}
}



//Vertica

if ($var == 'Vertica Objects') {

echo $row;
$row_value = $row;

for ($j = $row; $j <= $lastRow5; $j++)
{
  $var_object_unt = $worksheet5->getCell($value.$j)->getValue();

$var_object_null = trim($var_object_unt);



if ($lastRow5 == $j) {
  $ver[] = $j;
}


if ($var_object_null == NULL || $var_object_null == 'Informatica Objects' || $var_object_null == 'Shell Scripts' || $var_object_null == 'Maestro') {
 


$ver[] = $j; 



}


}




$d = $value;
$chars_1 = array($d);
while ($d < 'Z') $chars_1[] = ++$d;
foreach ($chars_1 as $key => $nextvalue) 

{

$object_type_count = $chars_1[1];
$new_modify_value = $chars_1[2];
$ver_new_count_t = 0;
$ver_modify_count_t = 0;

$ver_new_count_v= 0;
$ver_modify_count_v = 0;


$ver_new_count_s = 0;
$ver_modify_count_s = 0;


$ver_new_count_g = 0;
$ver_modify_count_g = 0;





for ($i=$row; $i < $ver[0]; $i++) { 
 

 $var_object_type =  $worksheet5->getCell($object_type_count.$i)->getValue();




if ($var_object_type == 'T') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $ver_new_count_t++;
}

if ($var_new_modify_type == 'Modify') {
  $ver_modify_count_t++;
}
}

if ($var_object_type == 'V') {

  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $ver_new_count_v++;
}

if ($var_new_modify_type == 'Modify') {
  $ver_modify_count_v++;


}
}




if ($var_object_type == 'S') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $ver_new_count_s++;
}

if ($var_new_modify_type == 'Modify') {
  $ver_modify_count_s++;
}
}


if ($var_object_type == 'G') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $ver_new_count_g++;
}

if ($var_new_modify_type == 'Modify') {
  $ver_modify_count_g++;
}
}



}
}
}



































//Maestro

if ($var == 'Maestro') {


$row_value = $row;

for ($j = $row; $j <= $lastRow5; $j++)
{
  $var_object_unt = $worksheet5->getCell($value.$j)->getValue();


$var_object_null = trim($var_object_unt);

if ($lastRow5 == $j) {
  $maes[] = $j;
}



if ($var_object_null == NULL || $var_object_null == 'Informatica Objects' || $var_object_null == 'Teradata Objects' || $var_object_null == 'Shell Scripts') {
  
$maes[] = $j; 

}



}




$d = $value;
$chars_1 = array($d);

while ($d < 'Z') $chars_1[] = ++$d;
foreach ($chars_1 as $key => $nextvalue) 

{

$object_type_count = $chars_1[1];
$new_modify_value = $chars_1[2];
$mas_new_count_82 = 0;
$mas_modify_count_82 = 0;
$mas_new_count_85 = 0;
$mas_modify_count_85 = 0;
$mas_new_count_92 = 0;
$mas_modify_count_92 = 0;



for ($i=$row; $i < $maes[0]; $i++) { 
 

 $var_object_type =  $worksheet5->getCell($object_type_count.$i)->getValue();

if ($var_object_type == '8.2') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $mas_new_count_82++;
}

if ($var_new_modify_type == 'Modify') {
  $mas_modify_count_82++;
}
}



if ($var_object_type == '8.5') {
  
 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $mas_new_count_85++;
}

if ($var_new_modify_type == 'Modify') {
  $mas_modify_count_85++;
}
}




if ($var_object_type == '9.2') {

 $var_new_modify_type =  $worksheet5->getCell($new_modify_value.$i)->getValue();
if ($var_new_modify_type == 'New') {
  $mas_new_count_92++;
}

if ($var_new_modify_type == 'Modify') {
  $mas_modify_count_92++;
}
}















}
}
}















 }        echo "</td><tr>";
         /*
       echo "</td><td>";
       echo $worksheet3->getCell('B'.$row)->getValue();
       echo "</td><td>";
       echo $worksheet3->getCell('C'.$row)->getValue();
       echo "</td><td>";
       echo $worksheet3->getCell('D'.$row)->getValue();
       echo "</td><td>";
       echo $worksheet3->getCell('E'.$row)->getValue();
       echo "</td><td>";
       echo $worksheet3->getCell('F'.$row)->getValue(); 
       echo "</td><tr>";*/
      
    } 
  //  $html_table .=  '</table>';




$output[] = array("shell_new_count_s","shell_modify_count_s","shell_new_count_b","shell_modify_count_b","shell_new_count_m","shell_modify_count_m","shell_new_count_t","shell_modify_count_t","shell_new_count_k","shell_modify_count_k","shell_new_count_d","shell_modify_count_d","shell_new_count_f","shell_modify_count_f","shell_new_count_x","shell_modify_count_x","inf_new_count_s","inf_modify_count_s","inf_new_count_sc","inf_modify_count_sc","inf_new_count_t","inf_modify_count_t","inf_new_count_m","inf_modify_count_m","inf_new_count_w","inf_modify_count_w","inf_new_count_mi","inf_modify_count_mi","td_new_count_t","td_modify_count_t","td_new_count_v","td_modify_count_v","td_new_count_s","td_modify_count_s","td_new_count_g","td_modify_count_g","mas_new_count_82","mas_modify_count_82","mas_new_count_85","mas_modify_count_85","mas_new_count_92","mas_modify_count_92","ver_new_count_t","ver_modify_count_t","ver_new_count_v","ver_modify_count_v","ver_new_count_s","ver_modify_count_s","ver_new_count_g","ver_modify_count_g");




foreach ($output as $key => $insert_value) {

 
for ($check_count=0; $check_count < sizeof($insert_value) ; $check_count++) { 

 

   $insert_object_cat_modify =0;
   $insert_object_cat_new = 0;

  if ($$insert_value[$check_count] != NULL) {


  $type_name_value = explode("_", $insert_value[$check_count]);

   $insert_object_name =  $type_name_value[0];
   $insert_object_type =  $type_name_value[3];
   $insert_object_check_cat = $type_name_value[1];

if ($insert_object_check_cat == 'new') {
  $insert_object_cat_new = $$insert_value[$check_count];
}

if ($insert_object_check_cat == 'modify') {
   $insert_object_cat_modify = $$insert_value[$check_count];
}




$insert_data = "INSERT INTO dg_table (cr_number, pmt_id, new_count, modify_count, name, object_name , object_type) VALUES ('$cr', '$pmt_id' , '$insert_object_cat_new' , '$insert_object_cat_modify', '$tmpfname','$insert_object_name' , '$insert_object_type') ";
mysqli_query($con, $insert_data); 
}


}



}


$myFile = "upload_test/".$filetoupload;

if (unlink($myFile)) {
echo "<script>alert('Data has been added!')</script>";
    echo "<script>window.open('index.php','_self')</script>";
}






}

    
/*





 $text_info_new = substr_count($html_table, 'New'); 
 $text_info_new_modify = substr_count($html_table, 'New/Modify'); 
 $text_info_modify = substr_count($html_table, 'Modify'); 
echo '<br>';

 echo $text_info_new - $text_info_new_modify;
 echo '<br>';
 echo $text_info_modify - $text_info_new_modify;
*/

?>

</body>
</html>