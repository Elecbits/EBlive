<!DOCTYPE html>

<?php

$dg_data = "SELECT name, cr_number, pmt_id, sum(new_count) as max_new_count , sum(modify_count) as max_modify_count, object_name, object_type  from dg_table group by  6 ;";

$run_pro = mysqli_query($con, $dg_data);

?>
<html>
<head>
	<title></title>
</head>
<body>
<div class="col-lg-8">
  
              
  <table class="table table-striped">
    <thead>
      <tr>
      
        <th>Object Type</th>
        <th>Total New Elements</th>
        <th>Total Modify Elements</th>


      </tr>
    </thead>

      <?php

while ($row_pro = mysqli_fetch_array($run_pro))
{



$cr_number = $row_pro['cr_number'];
$pmt_id = $row_pro['pmt_id'];
$new_count = $row_pro['max_new_count'];
$modify_count = $row_pro['max_modify_count'];
$filename = $row_pro['name'];
$objname = $row_pro['object_name'];
$objtype = $row_pro['object_type'];

      ?>



    <tbody>
      <tr>

    
       
       
        <td> <?php echo $objname ; ?></td>
        <td> <?php echo $new_count ; ?></td>
        <td> <?php echo $modify_count ; ?></td>


        
        

      </tr>
      
    </tbody>




<?php

}



?>


  </table>

  <form action="" method="post">
    <button type="submit"  name="chart"  class="btn" >Print Chart</button>
    </form>



<div class="container">
   
   <div id="piechart" style="width: 900px; height: 500px;"></div>
</div>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

<?php
$shell_sum = 1;
$mas_sum = 0;
$ver_sum = 0;
$td_sum = 0;
$inf_sum = 0;




  if (isset($_POST['chart'])) {

    
          
          $col_chart_mas ="SELECT sum(new_count) as new_one, sum(modify_count) as modify_one FROM dg_table where object_name='mas'  ";
$run_chart_mas = mysqli_query($con, $col_chart_mas);
$row_chart_mas = mysqli_fetch_array($run_chart_mas);

            $new_count_chart_mas = $row_chart_mas['new_one']  ;
         $modify_count_chart_mas = $row_chart_mas['modify_one'];

         $mas_sum = $new_count_chart_mas + $modify_count_chart_mas;


                   $col_chart_shell ="SELECT sum(new_count) as new_one, sum(modify_count) as modify_one FROM dg_table where object_name='shell'  ";
$run_chart_shell = mysqli_query($con, $col_chart_shell);
$row_chart_shell = mysqli_fetch_array($run_chart_shell);

            $new_count_chart_shell = $row_chart_shell['new_one']  ;
         $modify_count_chart_shell = $row_chart_shell['modify_one'];
   $shell_sum = $new_count_chart_shell + $modify_count_chart_shell;
       
          $col_chart_td ="SELECT sum(new_count) as new_one, sum(modify_count) as modify_one FROM dg_table where object_name='td'  ";
$run_chart_td = mysqli_query($con, $col_chart_td);
$row_chart_td = mysqli_fetch_array($run_chart_td);

            $new_count_chart_td = $row_chart_td['new_one']  ;
         $modify_count_chart_td = $row_chart_td['modify_one'];

          $td_sum = $new_count_chart_td + $modify_count_chart_td;

          $col_chart_ver ="SELECT sum(new_count) as new_one, sum(modify_count) as modify_one FROM dg_table where object_name='ver'  ";
$run_chart_ver = mysqli_query($con, $col_chart_ver);
$row_chart_ver = mysqli_fetch_array($run_chart_ver);

            $new_count_chart_ver = $row_chart_ver['new_one']  ;
         $modify_count_chart_ver = $row_chart_ver['modify_one'];

          $ver_sum = $new_count_chart_ver + $modify_count_chart_ver;


          $col_chart_inf ="SELECT sum(new_count) as new_one, sum(modify_count) as modify_one FROM dg_table where object_name='inf'  ";
$run_chart_inf = mysqli_query($con, $col_chart_inf);
$row_chart_inf = mysqli_fetch_array($run_chart_inf);

            $new_count_chart_inf = $row_chart_inf['new_one']  ;
         $modify_count_chart_inf = $row_chart_inf['modify_one'];

          $inf_sum = $new_count_chart_inf + $modify_count_chart_inf;

        }



  

?>



      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task','Hours per Day'],
          [' Shell',<?php echo $shell_sum;  ?>],
          ['Maestro', <?php echo $mas_sum; ?>],
          ['Teradata', <?php echo $td_sum; ?>],
          ['Informatica', <?php echo $inf_sum; ?>],
          ['Vertica', <?php echo $ver_sum; ?>],


        ]);

        var options = {
          title: 'Object Configuration'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>





</div>




</body>
</html>