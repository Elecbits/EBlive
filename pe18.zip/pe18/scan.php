<?php

require_once 'simple_html_dom.php';


// Create DOM from URL or file

echo file_get_html('http://mostls1coldpw54.itservices.sbc.com:90/scmcfnet/UFOJobs.cfm?job_id=E7B5CD3D-8232-4587-9D2B-0596FF16B799')->plaintext; 
// Find all images 


?>
