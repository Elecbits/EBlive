<!DOCTYPE html>
<?php

$con= mysqli_connect("localhost","root","","dgs");

if (mysqli_connect_errno () )
 {
    echo "Connection is not established";
}





?>




<html>
<head>
   <title>Listing of DG</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>

</head>
<body>





<div class="container">
<!-- <nav class="navbar navbar-default" role="navigation">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display 
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Brand</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling 
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Link</a></li>
        <li><a href="#">Link</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="#">Action</a></li>
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
            <li class="divider"></li>
            <li><a href="#">Separated link</a></li>
            <li class="divider"></li>
            <li><a href="#">One more separated link</a></li>
          </ul>
        </li>
      </ul>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Submit</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Link</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a>
          <ul class="dropdown-menu">
            <li><a href="#">Action</a></li>
            <li><a href="#">Another action</a></li>
            <li><a href="#">Something else here</a></li>
            <li class="divider"></li>
            <li><a href="#">Separated link</a></li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse 
  </div><!-- /.container-fluid 
</nav> -->

<br>
<br>

    <div class="row">
      <div class="col-lg-3  sidebar">
    <div class="mini-submenu">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </div>
    <div class="list-group">
        <span href="#" class="list-group-item active">
            Select the requirement
            <span class="pull-right" id="slide-submenu">
                <i class="fa fa-times"></i>
            </span>
        </span>
        <a href="list.php?cr" class="list-group-item">
            <i class="fa fa-comment-o"></i> CR Summary
        </a>
        <a href="list.php?objs" class="list-group-item">
            <i class="fa fa-comment-o"></i> Object Summary
        </a>
      <!--  <a href="list.php?Shell" class="list-group-item">
            <i class="fa fa-search"></i> Shell Scripts
        </a>
        <a href="list.php?Informatica" class="list-group-item">
            <i class="fa fa-user"></i> Informatica Objects
        </a>
        <a href="list.php?Teradata" class="list-group-item">
            <i class="fa fa-folder-open-o"></i> Teradata Objects
        </a>
        <a href="list.php?Maestro" class="list-group-item">
            <i class="fa fa-bar-chart-o"></i> Maestro 
        </a>
      <a href="list.php?Vertica" class="list-group-item">
            <i class="fa fa-bar-chart-o"></i> Vertica 
        </a> -->


    </div>        
</div>
































<div class="col-lg-8">



<?php

if(isset($_GET['cr'])) {
     

     include("cr.php");
   }
if(isset($_GET['objs'])) {
     

     include("object.php");
   }

if(isset($_GET['Shell'])) {
     

     include("shell.php");
   }

if(isset($_GET['Informatica'])) {
     

     include("inf.php");
   }


if(isset($_GET['Teradata'])) {
     

     include("td.php");
   }

if(isset($_GET['Maestro'])) {
     

     include("mas.php");
   }

if(isset($_GET['Vertica'])) {
     

     include("ver.php");
   }



?>





</div>


































   </div>
















</div>



























</body>
</html>