<!DOCTYPE html>
<html>
<head>
	<title></title>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>





</head>
<body>
<br><br>

<div class="container">
<form action="" method="post">

<button type="submit" name="test" class="btn btn-success">Get files</button>

<a href="list.php"><button type="button"  class="btn btn-info">List</button></a>


</form>

<br>




<table class="table ">
  <thead>
    <tr>
      
      <th>File Name</th>
      <th>Upload</th>
   
    </tr>
  </thead>

  <tbody>










<?php


if (isset($_POST['test'])) {

	$images_extension_array = array("xls","xlsx");

$dir = "upload_test/";
$dir_resource = opendir($dir);

$file_count = 0;
while (($file = readdir($dir_resource)) !== false) { // scan directory
  $extension_from = strrpos($file,"."); // isolate extension index/offset
  if ($extension_from && in_array(substr($file,$extension_from+1), $images_extension_array))
    $file_count ++; //if has extension and that extension is "associated" with an image, count
}







$dir = 'upload_test/';
$files = scandir($dir, 0);
for($i = 2; $i < count($files); $i++)
 {   



?>



    <tr>
     
      <td><?php echo $files[$i]; ?></td>
      <td><a href="index_1.php?file_name=<?php echo $files[$i]; ?>"><button type="button" class="btn btn-primary">Upload</button></a></td>
     
    </tr>
   
 





<?php



}


}

?>




 </tbody>

</table>

</div>






</body>
</html>